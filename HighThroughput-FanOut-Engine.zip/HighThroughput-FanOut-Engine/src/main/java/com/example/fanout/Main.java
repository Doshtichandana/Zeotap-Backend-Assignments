package com.example.fanout;

import com.example.fanout.config.AppConfig;
import com.example.fanout.orchestrator.FanOutEngine;

public class Main {
    public static void main(String[] args) throws Exception {
        AppConfig config = AppConfig.load("application.yaml");
        new FanOutEngine(config).start();
    }
}
