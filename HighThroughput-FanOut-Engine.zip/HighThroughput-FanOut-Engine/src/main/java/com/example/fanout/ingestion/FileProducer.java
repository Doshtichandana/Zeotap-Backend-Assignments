package com.example.fanout.ingestion;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.BlockingQueue;

public class FileProducer implements Runnable {

    private final String filePath;
    private final BlockingQueue<String> queue;

    public FileProducer(String filePath, BlockingQueue<String> queue) {
        this.filePath = filePath;
        this.queue = queue;
    }

    @Override
    public void run() {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(filePath), StandardCharsets.UTF_8))) {

            String line;
            while ((line = reader.readLine()) != null) {
                queue.put(line);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

