package com.example.fanout.metrics;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class Metrics {

    private final long startTime = System.currentTimeMillis();
    private final AtomicLong total = new AtomicLong();
    private final ConcurrentHashMap<String, AtomicLong> success = new ConcurrentHashMap<>();

    public void incrementTotal() {
        total.incrementAndGet();
    }

    public void success(String sink) {
        success.computeIfAbsent(sink, k -> new AtomicLong()).incrementAndGet();
    }

    public void print() {
        long elapsed = (System.currentTimeMillis() - startTime) / 1000;
        long throughput = elapsed > 0 ? total.get() / elapsed : total.get();

        System.out.println("\n---- STATUS ----");
        System.out.println("Total Processed: " + total.get());
        System.out.println("Throughput: " + throughput + " rec/sec");

        success.forEach((k,v) ->
                System.out.println(k + " Success: " + v.get()));

        System.out.println("----------------");
    }
}
