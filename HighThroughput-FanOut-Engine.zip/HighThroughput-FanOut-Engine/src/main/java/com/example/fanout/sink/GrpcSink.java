package com.example.fanout.sink;

public class GrpcSink extends AbstractSink {
    public GrpcSink(int rate) { super("GRPC", rate); }
}
