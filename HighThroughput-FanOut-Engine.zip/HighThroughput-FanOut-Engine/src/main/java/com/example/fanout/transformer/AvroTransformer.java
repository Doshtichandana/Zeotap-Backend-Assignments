package com.example.fanout.transformer;

public class AvroTransformer implements Transformer {
    public Object transform(String record) {
        return "AVRO:" + record;
    }
}
