package com.example.fanout.sink;

import com.example.fanout.config.AppConfig.SinkConfig;

public class SinkFactory {

    public static Sink create(SinkConfig config) {
        return switch (config.type.toUpperCase()) {
            case "REST" -> new RestSink(config.rateLimit);
            case "GRPC" -> new GrpcSink(config.rateLimit);
            case "MQ" -> new MqSink(config.rateLimit);
            case "DB" -> new DbSink(config.rateLimit);
            default -> throw new IllegalArgumentException("Unknown sink type");
        };
    }
}
