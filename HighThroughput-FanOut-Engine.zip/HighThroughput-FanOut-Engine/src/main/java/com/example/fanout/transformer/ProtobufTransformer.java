package com.example.fanout.transformer;

public class ProtobufTransformer implements Transformer {
    public Object transform(String record) {
        return record.getBytes();
    }
}
