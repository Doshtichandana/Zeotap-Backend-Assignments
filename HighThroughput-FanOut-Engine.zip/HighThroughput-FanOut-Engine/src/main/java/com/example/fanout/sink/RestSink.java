package com.example.fanout.sink;

public class RestSink extends AbstractSink {
    public RestSink(int rate) { super("REST", rate); }
}
