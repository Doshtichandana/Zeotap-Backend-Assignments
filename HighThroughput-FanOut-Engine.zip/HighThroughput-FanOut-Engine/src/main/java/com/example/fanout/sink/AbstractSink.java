package com.example.fanout.sink;

public abstract class AbstractSink implements Sink {

    private final String name;
    private final int rateLimit;
    private long lastRefillTime;
    private int tokens;

    protected AbstractSink(String name, int rateLimit) {
        this.name = name;
        this.rateLimit = rateLimit;
        this.tokens = rateLimit;
        this.lastRefillTime = System.currentTimeMillis();
    }

    protected synchronized void acquire() throws InterruptedException {
        long now = System.currentTimeMillis();
        if (now - lastRefillTime >= 1000) {
            tokens = rateLimit;
            lastRefillTime = now;
        }

        while (tokens == 0) {
            wait(1);
        }

        tokens--;
    }

    public void send(Object data) throws Exception {
        acquire();
        Thread.sleep(5);
    }

    public String name() {
        return name;
    }
}

