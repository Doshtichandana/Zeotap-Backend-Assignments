package com.example.fanout.transformer;

public interface Transformer {
    Object transform(String record);
}
