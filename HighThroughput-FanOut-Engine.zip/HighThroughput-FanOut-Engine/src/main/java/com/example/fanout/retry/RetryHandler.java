package com.example.fanout.retry;

import com.example.fanout.metrics.Metrics;
import com.example.fanout.sink.Sink;

import java.io.FileWriter;

public class RetryHandler {

    public static void process(Sink sink, Object data, Metrics metrics, String dlqPath) {
        int attempts = 0;

        while (attempts < 3) {
            try {
                sink.send(data);
                metrics.success(sink.name());
                return;
            } catch (Exception e) {
                attempts++;
            }
        }

        try (FileWriter fw = new FileWriter(dlqPath, true)) {
            fw.write(data.toString() + "\n");
        } catch (Exception ignored) {}
    }
}
