package com.example.fanout.sink;

public class DbSink extends AbstractSink {
    public DbSink(int rate) { super("DB", rate); }
}
