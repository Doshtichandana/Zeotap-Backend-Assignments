package com.example.fanout.config;

import org.yaml.snakeyaml.Yaml;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class AppConfig {

    public String filePath;
    public int queueSize;
    public String dlqPath;
    public List<SinkConfig> sinks;

    public static class SinkConfig {
        public String type;
        public int rateLimit;
    }

    public static AppConfig load(String path) throws Exception {
        Yaml yaml = new Yaml();
        try (InputStream in = Files.newInputStream(Path.of(path))) {
            return yaml.loadAs(in, AppConfig.class);
        }
    }
}
