package com.example.fanout.sink;

public class MqSink extends AbstractSink {
    public MqSink(int rate) { super("MQ", rate); }
}
