package com.example.fanout.orchestrator;

import com.example.fanout.config.AppConfig;
import com.example.fanout.ingestion.FileProducer;
import com.example.fanout.metrics.Metrics;
import com.example.fanout.retry.RetryHandler;
import com.example.fanout.sink.*;
import com.example.fanout.transformer.*;

import java.util.*;
import java.util.concurrent.*;

public class FanOutEngine {

    private final AppConfig config;

    public FanOutEngine(AppConfig config) {
        this.config = config;
    }

    public void start() throws Exception {

        BlockingQueue<String> queue = new ArrayBlockingQueue<>(config.queueSize);
        Metrics metrics = new Metrics();

        List<Sink> sinks = config.sinks.stream()
                .map(SinkFactory::create)
                .toList();

        Map<String, Transformer> transformers = Map.of(
                "REST", new JsonTransformer(),
                "GRPC", new ProtobufTransformer(),
                "MQ", new XmlTransformer(),
                "DB", new AvroTransformer()
        );

        ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

        scheduler.scheduleAtFixedRate(metrics::print, 5, 5, TimeUnit.SECONDS);

        executor.submit(new FileProducer(config.filePath, queue));

        while (true) {
            String record = queue.poll(1, TimeUnit.SECONDS);
            if (record == null) break;

            metrics.incrementTotal();

            for (Sink sink : sinks) {
                Transformer transformer = transformers.get(sink.name());
                Object transformed = transformer.transform(record);

                executor.submit(() ->
                        RetryHandler.process(sink, transformed, metrics, config.dlqPath)
                );
            }
        }

        executor.shutdown();
        scheduler.shutdown();

        System.out.println("Processing Complete.");
        metrics.print();
    }
}
