package com.example.fanout.transformer;

public class XmlTransformer implements Transformer {
    public Object transform(String record) {
        return "<data>" + record + "</data>";
    }
}
