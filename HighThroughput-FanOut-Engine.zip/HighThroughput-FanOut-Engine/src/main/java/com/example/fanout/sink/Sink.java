package com.example.fanout.sink;

public interface Sink {
    void send(Object data) throws Exception;
    String name();
}
