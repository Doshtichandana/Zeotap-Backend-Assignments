package com.example.fanout.transformer;

public class JsonTransformer implements Transformer {
    public Object transform(String record) {
        return "{\"data\":\"" + record + "\"}";
    }
}
